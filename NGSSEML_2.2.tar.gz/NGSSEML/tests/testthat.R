library(testthat)
library(NGSSEML)

test_check("NGSSEML")
